package control;

import dao.ProductoDAO;
import java.sql.Connection;
import entidades.Producto;

public class ProductoControl {
    private ProductoDAO ProductoDAO;
    
    public ProductoControl(Connection Connection){
        ProductoDAO = new ProductoDAO(Connection);
    }
    
}
