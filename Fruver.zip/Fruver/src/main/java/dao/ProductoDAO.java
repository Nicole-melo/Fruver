package dao;

import entidades.Producto;
import java.sql.*;
import java.util.*;

public class ProductoDAO {

    private Connection connection;

    // Constructor recibe una conexión válida
    public ProductoDAO(Connection connection) {
        this.connection = connection;
    }

    public void insertar(Producto p) {
        String sql = "INSERT INTO producto (Nombre, Categoria, Cantidad, Precio, fecha_ingreso) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getCategoria());
            ps.setInt(3, p.getCantidad());
            ps.setDouble(4, p.getPrecio());
            ps.setDate(5, new java.sql.Date(p.getFechaIngreso().getTime()));
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Producto> listar() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM producto";
        try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Producto p = new Producto();
                p.setId(rs.getInt("id"));
                p.setNombre(rs.getString("nombre"));
                p.setCategoria(rs.getString("categoria"));
                p.setCantidad(rs.getInt("cantidad"));
                p.setPrecio(rs.getDouble("precio"));
                p.setFechaIngreso(rs.getDate("fecha_ingreso"));
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Puedes agregar los métodos actualizar y eliminar si deseas
}
