package view;

import dao.ProductoDAO;
import entidades.Producto;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.util.Date;

public class Fruver extends JInternalFrame {
    private JTextField txtNombre, txtCategoria, txtCantidad, txtPrecio;
    private JButton btnGuardar;
    private JSpinner spFechaIngreso;
    private ProductoDAO productoDAO;

    public Fruver(Connection connection) {
        super("Registrar Producto", true, true, true, true);
        setSize(400, 300);
        setLayout(new BorderLayout());

        productoDAO = new ProductoDAO(connection);

        // Panel de formulario
        JPanel panel = new JPanel(new GridLayout(6, 2, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panel.add(txtNombre);

        panel.add(new JLabel("Categoría:"));
        txtCategoria = new JTextField();
        panel.add(txtCategoria);

        panel.add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField();
        panel.add(txtCantidad);

        panel.add(new JLabel("Precio:"));
        txtPrecio = new JTextField();
        panel.add(txtPrecio);

        panel.add(new JLabel("Fecha Ingreso:"));
        spFechaIngreso = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editor = new JSpinner.DateEditor(spFechaIngreso, "yyyy-MM-dd");
        spFechaIngreso.setEditor(editor);
        panel.add(spFechaIngreso);

        btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(this::guardarProducto);
        panel.add(btnGuardar);

        add(panel, BorderLayout.CENTER);
        setVisible(true);
    }

    private void guardarProducto(ActionEvent evt) {
        try {
            String nombre = txtNombre.getText();
            String categoria = txtCategoria.getText();
            int cantidad = Integer.parseInt(txtCantidad.getText());
            double precio = Double.parseDouble(txtPrecio.getText());
            Date fechaIngreso = (Date) spFechaIngreso.getValue();

            Producto p = new Producto();
            p.setNombre(nombre);
            p.setCategoria(categoria);
            p.setCantidad(cantidad);
            p.setPrecio(precio);
            p.setFechaIngreso(fechaIngreso);

            productoDAO.insertar(p);
            JOptionPane.showMessageDialog(this, "Producto insertado correctamente");
            limpiarCampos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al insertar: " + e.getMessage());
        }
    }

    private void limpiarCampos() {
        txtNombre.setText("");
        txtCategoria.setText("");
        txtCantidad.setText("");
        txtPrecio.setText("");
        spFechaIngreso.setValue(new Date());
    }
}
