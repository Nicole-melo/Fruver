package control;

import dao.ProductoDAO;
import entidades.Producto;

import java.util.List;

public class ProductoControl {
    private final ProductoDAO dao;

    public ProductoControl() {
        dao = new ProductoDAO();
    }

    public List<Producto> listar() {
        return dao.listar();
    }

    public boolean insertar(String nombre, String descripcion, double precio, int stock, int categoriaId, int proveedorId) {
        Producto p = new Producto();
        p.setNombre(nombre);
        p.setDescripcion(descripcion);
        p.setPrecio(precio);
        p.setStock(stock);
        p.setCategoriaId(categoriaId);
        p.setProveedorId(proveedorId);
        return dao.insertar(p);
    }

    public boolean actualizar(int id, String nombre, String descripcion, double precio, int stock, int categoriaId, int proveedorId) {
        Producto p = new Producto();
        p.setProductoId(id);
        p.setNombre(nombre);
        p.setDescripcion(descripcion);
        p.setPrecio(precio);
        p.setStock(stock);
        p.setCategoriaId(categoriaId);
        p.setProveedorId(proveedorId);
        return dao.actualizar(p);
    }

    public boolean eliminar(int id) {
        return dao.eliminar(id);
    }
}
