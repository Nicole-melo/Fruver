package vista;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Sistema Fruver");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        JDesktopPane desktop = new JDesktopPane();
        frame.add(desktop);

        ProductoInternalFrame productoFrame = new ProductoInternalFrame();
        desktop.add(productoFrame);
        productoFrame.setVisible(true);

        frame.setVisible(true);
    }
}

