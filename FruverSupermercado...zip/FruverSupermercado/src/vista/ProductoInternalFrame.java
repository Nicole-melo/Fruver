package vista;

import dao.ProductoDAO;
import entidades.Producto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class ProductoInternalFrame extends JInternalFrame {
    private JTextArea textArea;
    private ProductoDAO dao = new ProductoDAO();

    public ProductoInternalFrame() {
        setTitle("Gestión de Productos");
        setClosable(true);
        setMaximizable(true);
        setSize(500, 400);
        setLayout(new BorderLayout());

        textArea = new JTextArea();
        JButton btnCargar = new JButton("Cargar Productos");
        btnCargar.addActionListener(this::cargarProductos);

        add(new JScrollPane(textArea), BorderLayout.CENTER);
        add(btnCargar, BorderLayout.SOUTH);
    }

    private void cargarProductos(ActionEvent e) {
        List<Producto> lista = dao.listar();
        textArea.setText("");
        for (Producto p : lista) {
            textArea.append(p.getProductoId() + " - " + p.getNombre() + " - $" + p.getPrecio() + "\n");
        }
    }
}
